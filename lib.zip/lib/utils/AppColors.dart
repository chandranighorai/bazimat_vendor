import 'package:flutter/material.dart';

class AppColors {
  static Color buttonColor = Color(0xFF490305);
  static Color acceptColor = Color(0xFF00d309);
  static Color cancelColor = Color(0xFFe00202);
}
