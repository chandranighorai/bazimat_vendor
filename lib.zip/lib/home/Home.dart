import 'package:bazimat_vendor_app/drawer/Navigation.dart';
import 'package:bazimat_vendor_app/home/HomePageList.dart';
import 'package:bazimat_vendor_app/utils/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Home extends StatefulWidget {
  const Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String dateFormatter;
  GlobalKey<ScaffoldState> ScaffFoldState = GlobalKey<ScaffoldState>();
  List dashBoardData = [
    {"image": "images/dollar.png", "total": "\u20B9300", "type": "Earning"},
    {"image": "images/received.png", "total": "23", "type": "Total Orders"},
    {"image": "images/sent.png", "total": "0", "type": "Today's Orders"},
    {"image": "images/discard.png", "total": "3", "type": "cancel Orders"}
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    var now = new DateTime.now();
    var formatter = new DateFormat.yMMMMd('en_US');
    dateFormatter = formatter.format(now);
    print(dateFormatter.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: ScaffFoldState,
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(
              Icons.menu,
              color: AppColors.buttonColor,
            ),
            onPressed: () => ScaffFoldState.currentState.openDrawer()),
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Text(
              "Home",
              style: TextStyle(color: AppColors.buttonColor),
            ),
            Spacer(),
            Text(
              dateFormatter.toString(),
              style: TextStyle(
                  color: AppColors.buttonColor,
                  fontSize: MediaQuery.of(context).size.width * 0.04),
            )
          ],
        ),
      ),
      drawer: Navigation(),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: GridView.builder(
            itemCount: dashBoardData.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: (MediaQuery.of(context).size.width /
                    MediaQuery.of(context).size.height *
                    1.8)),
            itemBuilder: (BuildContext context, int index) {
              return HomePageList(dataList: dashBoardData[index]);
            }),
      ),
    );
  }
}
